file = open("speedtest.txt","r")

contents = file.read()

file = open("speedtest_log.txt","r+")

ogcontents = file.read()

print(ogcontents)

file.write(contents)

